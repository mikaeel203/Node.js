import dotenv from "dotenv";
import express from "express";
import cors from "cors";
import employeesRouter from "./routes/employees.js";

// load environment variables
dotenv.config();

const app = express();

// enable cors and json parsing
app.use(cors());
app.use(express.json());

// define routes
app.use("/employees", employeesRouter);

// start server
app.listen(3000, () => {
    console.log("https://localhost:3000");    
});

console.log(30);
