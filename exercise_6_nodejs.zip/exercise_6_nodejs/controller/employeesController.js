import { 
    getSingleEmployee, 
    getAllEmployees, 
    addEmployee, 
    deleteSingleEmployee, 
    deleteAllEmployees, 
    getEmployeeSA 
} from "../models/employeesDB.js";

// fetch all employees
const getAllEmployeesCon = async (req, res) => {
    res.json(await getAllEmployees());
};

// fetch a single employee by id
const getSingleEmployeeCon = async (req, res) => {
    res.json(await getSingleEmployee(req.params.employee_id));
};

// add a new employee
const addEmployeeCon = async (req, res) => {
    let { first_name, last_name, email, phone_number, salary, department_id } = req.body; 
    console.log(req.body);
    res.json({
        employees: await addEmployee(first_name, last_name, email, phone_number, salary, department_id),
    });
};

// delete an employee by id
const deleteSingleEmployeeCon = async (req, res) => {
    res.json({
        employees: await deleteSingleEmployee(req.params.employee_id),
    });
};

// delete all employees
const deleteAllEmployeesCon = async (req, res) => {
    res.json(await deleteAllEmployees());
};

// fetch employees from department id 1
const getEmployeeSACon = async (req, res) => {
    res.json(await getEmployeeSA());
};

export { 
    getAllEmployeesCon, 
    getSingleEmployeeCon, 
    addEmployeeCon, 
    deleteSingleEmployeeCon, 
    deleteAllEmployeesCon, 
    getEmployeeSACon 
};
