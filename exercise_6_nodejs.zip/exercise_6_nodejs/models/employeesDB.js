import { pool } from "../config/config.js";

// fetch all employees
const getAllEmployees = async () => {
    let [data] = await pool.query("SELECT * FROM employees");
    return data;
};

// fetch a single employee by id
const getSingleEmployee = async (employee_id) => {
    let [data] = await pool.query("SELECT * FROM employees WHERE employee_id=?", [employee_id]);
    return data;
};

// add a new employee
const addEmployee = async (first_name, last_name, email, phone_number, salary, department_id) => {
    let [data] = await pool.query("INSERT INTO employees (first_name, last_name, email, phone_number, salary, department_id) VALUES (?, ?, ?, ?, ?, ?)", 
        [first_name, last_name, email, phone_number, salary, department_id]);
    return data;
};

// delete an employee by id
const deleteSingleEmployee = async (employee_id) => {
    await pool.query("DELETE FROM employees WHERE employee_id=?", [employee_id]);
    console.log(await getAllEmployees());
};

// delete all employees
const deleteAllEmployees = async () => {
    await pool.query("DELETE FROM employees");
    console.log(await getAllEmployees());
};

// fetch employees from department id 1
const getEmployeeSA = async () => {
    let [data] = await pool.query("SELECT * FROM employees WHERE department_id=1");
    return data;
};

export { 
    getAllEmployees, 
    getSingleEmployee, 
    addEmployee, 
    deleteSingleEmployee, 
    deleteAllEmployees, 
    getEmployeeSA 
};
