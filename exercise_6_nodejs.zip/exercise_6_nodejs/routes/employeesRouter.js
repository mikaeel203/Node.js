import express from "express";
import { 
    getAllEmployeesCon, 
    getSingleEmployeeCon, 
    addEmployeeCon, 
    deleteAllEmployeesCon, 
    deleteSingleEmployeeCon, 
    getEmployeeSACon 
} from "../controllers/employeesController.js";

const router = express.Router();

// define routes
router.get("/", getAllEmployeesCon);
router.get("/:employee_id", getSingleEmployeeCon);
router.post("/", addEmployeeCon);
router.delete("/:employee_id", deleteSingleEmployeeCon);
router.delete("/", deleteAllEmployeesCon);
router.get("/department/:department_id", getEmployeeSACon);

// export router
export default router;
