import express from 'express'
import mysql from 'mysql2/promise' //   /promise allows you to use async and await 
import {config} from 'dotenv'
config()

const pool = mysql.createPool({
    host: process.env.HOST,
    user: process.env.USER,
    password: process.env.PASSWORD,
    database: process.env.DATABASE
})

const app = express()
app.use(express.json())


//return all products from the table
app.get ('/products', async(req, res)=>{
    res.json({products: await getProductsTable()})
})

//returns all users from the table
app.get ('/users', async(req, res)=>{
    res.json({users: await getUsersTable()})
})

//return a single product based on their id
app.get('/products/:product_code',  async(req, res) => {
    res.json({
        products: await getProduct(req.params.product_code)
    })
})

//return a single user based on their id
app.get('/users/:id',  async(req, res) => {
    res.json({
        users: await getUser(req.params.id)
    })
})

//add new products
app.post('/products', async(req, res)=>{
    let {product_code, product_name, products_price, product_quantity} = req.body
    res.json({
        products: await addNewProduct(product_code, product_name, products_price, product_quantity)
    })
})

//add new user
app.post('/users', async(req, res)=>{
    let {email, first_name, last_name, password} = req.body
    res.json({
        users: await addNewUser(email, first_name, last_name, password)
    })
})

//delete products from db based in pk
app.delete('/products', async(req, res) =>{
    res.json({
        products: await deleteProduct('baro1')
    })
})

//delete user from db based on pk
app.delete('/users', async(req, res) =>{
    res.json({
        users: await deleteUser(1)
    })
})

app.patch ('/products', async(req, res)=>{
    res.json({
        products: await updateProducts ('tac05', 'tacos', 50.10, 100, 'baro1')
    })
})


// =======================================
app.listen(3030, () => {
    console.log('http://localhost:3030');
})
//========================================


// xxxxxxxxxxxxxxxxxxXXXXXXXXXX FUNCTIONS XXXXXXXXXXxxxxxxxxxxxxxxxx

//function for returning all data in the employees table
const getProductsTable = async() =>{
    let [data] = await pool.query("SELECT * FROM shopleft_database.products;")
    return data
}

//function for returning all data in the users table
const getUsersTable = async()=>{
    let [data] = await pool.query("SELECT * FROM shopleft_database.users;")
    return data
}

//function for getting an product data (single) based on their  ID
const getProduct = async(pk) =>{
    let [data] = await pool.query ("SELECT * FROM shopleft_database.products WHERE product_code = ?", [pk])
    return data
}

const getUser = async(pk) =>{
    let [data] = await pool.query ("SELECT * FROM shopleft_database.users WHERE id = ?", [pk])
    return data
}

const addNewUser = async(email, first_name, last_name, password) =>{
    await pool.query ("INSERT INTO `shopleft_database`.`users` (`email`, `first_name`, `last_name`, `password`) VALUES (?, ?, ?, ?);", [email, first_name, last_name, password])
    return await getUsersTable()
}

// add new product
const addNewProduct = async(product_code, product_name, products_price, product_quantity) =>{
    await pool.query ("INSERT INTO `shopleft_database`.`products` (`product_code`, `product_name`, `product_price`, `product_quantity`) VALUES (?, ?, ?, ?);", [product_code, product_name, products_price, product_quantity])
    return await getProductsTable()
}

//delete product from db based on pk
const deleteProduct = async (product_code) =>{
    await pool.query ("DELETE FROM `shopleft_database`.`products` WHERE (`product_code` = ?);", [product_code])
    return await getProductsTable()
}

//remove user from db based on pk
const deleteUser = async (id) =>{
    await pool.query ("DELETE FROM `shopleft_database`.`users` WHERE (`id` = ?);", [id])
    return await getUsersTable()
}

const updateProducts = async (product_code, product_name, products_price, product_quantity, pk)=>{
    await pool.query ("UPDATE `shopleft_database`.`products` SET `product_code` = ?, `product_name` = ?, `product_price` = ?, `product_quantity` = ? WHERE (`product_code` = ?);", [product_code, product_name, products_price, product_quantity, pk])
    return await getProductsTable()
}
