drop database if exists shopleft_database;
create database shopleft_database; 
use shopleft_database;

create table users (
id int primary key auto_increment,
email varchar (225),
first_name varchar (45),
last_name varchar (45),
password varchar (225));

insert into users (id, email, first_name, last_name, password)
values
	(1, "matthew@lifechoicesco.za", "mathew", "brown", "matthewbrown"),
    (2, "mikaeel@amazon.co.za", "mikaeel", "sedick", "ThisIsMikaeel");

create table products (
product_code varchar (40) primary key,
product_name varchar (45),
product_price decimal (5,2), 
product_quantity int
);

insert into products (product_code, product_name, product_price, product_quantity)
values
	("baro1", "Bar One", 9.99, 20),
    ("hand1", "Handy Andy", 19.00, 5),
    ("pota1", "potatoes", 38.99, 10),
    ("chik1", "chicken", 79.99, 15),
    ("stk11", "steak", 110.99, 8),
    ("cnug1", "chicken nuggets", 49.99, 25);
