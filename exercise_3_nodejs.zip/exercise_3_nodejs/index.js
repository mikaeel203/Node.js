import mysql from 'mysql2/promise'
import {config} from 'dotenv'
config()

//connect the database
const pool = mysql.createPool({
    hostname: process.env.HOSTNAME,
    user: process.env.USER, 
    password: process.env.PASSWORD,
    database: process.env.DATABASE
})

//get products table
const getProducts  = async() => {
    let [data] = await pool.query ('SELECT * FROM shopleft_database.products') 
    return data 
} 
    console.log(await getProducts());

//get users table
const getUsers  = async() => {
    let [data] = await pool.query ('SELECT * FROM shopleft_database.users') 
    return data 
}
    console.log(await getUsers());



//DELETE QUERY
const deleteQuery = async(pk) =>{
    await pool.query ('delete from shopleft_database.products where (product_code = ?)',[pk])
    return await getProducts()
}
await deleteQuery ('baro1')

// const deleteQuery = async (pk) => {
//     try {
//         const query = 'DELETE FROM shopleft_database.products WHERE product_code = ?';
//         const [result] = await pool.query(query, [pk]);

//         if (result.affectedRows > 0) {
//             console.log('Product with code ? deleted successfully.', [pk]);
//         } else {
//             console.log('No product found with code ?.', [pk]);
//         }
//     } catch (error) {
//         console.error('Error in deleting product:', error);
//     }
// };
// deleteQuery('chik1')


// insert query 
const insertQuery = async(pk, productName, product_price, product_quantity) =>{
    pool.query ("INSERT INTO `shopleft_database`.`products` (`product_code`, `product_name`, `product_price`, `product_quantity`) VALUES (?, ?, ?, ?);", [pk, productName, product_price, product_quantity])
    return await getProducts()
} 
await insertQuery ('p1za', 'pizza', 39.99, 5)


 //update
 const updateQuery = async(pk, newName, newPrice, newQuantity) =>{
    await pool.query ( "UPDATE `shopleft_database`.`products` SET `product_name` = ?, `product_price` = ?, `product_quantity` = ? WHERE (`product_code` = ?);", [newName, newPrice, newQuantity, pk])
    return await getProducts()
}
await updateQuery ('andy1','Andy Hands', 10.99, 50);



 