import express from 'express'
import mysql from 'mysql2/promise' //   /promise allows you to use async and await 
import {config} from 'dotenv'
config()

const pool = mysql.createPool({
    host: process.env.HOST,
    user: process.env.USER,
    password: process.env.PASSWORD,
    database: process.env.DATABASE
})

const app = express()
app.use(express.json())

//return all employees from the table
app.get ('/employees', async(req, res)=>{
    res.json({employees: await getEmployeesTable()})
})

//return a single employee based on their id
app.get('/employees/:employee_id',  async(req, res) => {
    res.json({
        employees: await getEmployee(req.params.employee_id)
    })
})

//add an employee to the database and display the whole one to see if it worked
app.post('/employees', async(req, res)=>{
    let {first_name, last_name, email, phone_number, department, salary} = req.body
    res.json({
        employees: await addNewEmployee(first_name, last_name, email, phone_number, department, salary)
    })
})

//remove employee in the table
app.delete('/employees/',  async(req, res) => {
    res.json({
        employees: await deleteEmployee(1)
    })
})
 
//update a single employee data
app.patch('/employees', async(req, res)=>{
    res.json({
        employees: await updateEmployee('mikaeel', 'sedick', 'mikaeelsedick@gmail.com', '555-9911', 'Software Engineering', 100000.00, 3)
    })
})


app.listen(3030, () => {
    console.log('http://localhost:3030');
})



// FUNCTIONS
//function for returning all data in the employees table
const getEmployeesTable = async() =>{
    let [data] = await pool.query("SELECT * FROM pick_n_steal.employees;")
    return data
}

//function for getting an employee data (single) base dontheir employyee ID
const getEmployee = async(pk) =>{
    let [data] = await pool.query ("SELECT * FROM pick_n_steal.employees WHERE employee_id = ?", [pk])
    return data
}

//add new employee function
const addNewEmployee = async(first_name, last_name, email, phone_number, department, salary) =>{
    await pool.query("INSERT INTO `pick_n_steal`.`employees` (`first_name`, `last_name`, `email`, `phone_number`, `department`, `salary`) VALUES (?, ?, ?, ?, ?, ?);", [first_name, last_name, email, phone_number, department, salary])
    return await getEmployeesTable()    
}

//Delete employee from a table 
const deleteEmployee = async(pk)=>{
    await pool.query("DELETE FROM `pick_n_steal`.`employees` WHERE (`employee_id` = ?);", [pk])
    return await getEmployeesTable()
}

//update employee data function 
const updateEmployee = async(first_name, last_name, email, phone_number, department, salary, employee_id)=>{
    await pool.query("UPDATE `pick_n_steal`.`employees` SET `first_name` = ?, `last_name` = ?, `email` = ?, `phone_number` = ?, `department` = ?, `salary` = ? WHERE (`employee_id` = ?);", [first_name, last_name, email, phone_number, department, salary, employee_id])
    return await getEmployeesTable()
}

/* In the body
{"first_name":"Jennifer", 
"last_name":"Lawrence", 
"email": "jenniferlawrence@gmail.com", 
"phone_number":"555-55555", 
"department":"Acting", 
"salary":1000000.00}
*/