import express from 'express'

const app = express ()
const PORT = process.env.PORT || 3000

//get method
app.get('/employees', (req, res)=>{
    res.json({
        message:"GET method for employees"
    })
})

app.get('/managers', (req, res)=>{
    res.json({
        message:"GET method for managers"
    })
})

//post method
app.post('/employees', (req, res)=>{
    res.json({
        message:"POST method for employees"
    })
})


//patch method
app.patch('/managers/', (req, res) => {  //:id is the route paramter. It acts as a variable in the route || placeholder for dynamic value in the url
    res.json({
        message: "PATCH method for updating a manager"
    });
});


//delete method
app.delete('/managers/', (req, res) => {
    res.json({
        message: "DELETE method for deleting a manager"
    });
});



app.listen(PORT, ()=>{  
    console.log('http://localhost:' + PORT);
})