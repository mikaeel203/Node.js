
// // Optional: Add a server
// const http = require("http");
// const server = http.createServer((req, res) => {
//   res.writeHead(200, { "Content-Type": "text/plain" });
//   res.end("Hello, World!");
// });
// server.listen(3000, () => console.log("Server running on port 3000"));


import express from 'express'

const app = express ()
const PORT = process.env.PORT || 3000

//get method
app.get('/products', (req, res)=>{
    res.json({
        message:"this is the GET products"
    })
})

app.get('/users', (req, res)=>{
    res.json({
        message:"this is the GET users"
    })
})

//post method
app.post('/products', (req, res)=>{
    res.json({
        message:"This is the post method for the PRODUCTS"
    })
})

app.post('/users', (req, res)=>{
    res.json({
        message:"This is the post method for the USERSSSS"
    })
})





app.listen(PORT, ()=>{  
    console.log('http://localhost:' + PORT);
})